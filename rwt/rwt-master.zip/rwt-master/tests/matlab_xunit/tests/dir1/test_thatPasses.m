function test_suite = test_thatPasses
initTestSuite;

function test_case
assertTrue(true);
