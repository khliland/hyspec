% helper_that is not a test file.

function y = helper_that(x)
y = x;
