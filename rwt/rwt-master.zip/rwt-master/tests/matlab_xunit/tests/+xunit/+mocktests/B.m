% Class B is not a TestCase subclass.

classdef B
end