% test_that.m is a subfunction test file.
function test_suite = test_this
initTestSuite

function test_the_other
a = magic(3);

function test_nifty
b = magic(5);
