function testFoobar
%testFoobar Passing M-file test

%   Steven L. Eddins
%   Copyright 2008 The MathWorks, Inc.